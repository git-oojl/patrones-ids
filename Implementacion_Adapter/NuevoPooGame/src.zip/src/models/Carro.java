package models;

import processing.core.PApplet;

public class Carro extends Figura {

    public Carro() {
        super();
        // Default size for a car
        this.dimension = new Dimension(100, 40); 
    }

    @Override
    public void dibujar(PApplet p) {
        configurarPropiedades(p); // Sets color and border

        float x = this.posicion.getX();
        float y = this.posicion.getY();
        
        // 1. Draw Body (The top part)
        // We use the full width and height
        p.rect(x, y, dimension.getHorizontal(), dimension.getVertical());

        // 2. Draw Wheels (Composite parts)
        // We calculate their position relative to the car's X and Y
        p.fill(0); // Make wheels black
        
        // Left Wheel
        p.ellipse(x + 15, y + dimension.getVertical(), 20, 20);
        
        // Right Wheel
        p.ellipse(x + dimension.getHorizontal() - 15, y + dimension.getVertical(), 20, 20);
        
        // Reset color for next draw
        p.fill(this.color); 
    }
    
    @Override
    public boolean mouseIsOver(int coordMouseX, int coordMouseY) {
        return true; 
    }
}