package models;

import processing.core.PApplet;

public class Elipse extends Figura {
    
    // We can rely on Figura's default constructor, 
    // or add one if we want specific circle defaults.
    public Elipse() {
        super();
    }
    
    @Override
    public void dibujar(PApplet p) {
        // Reuse the style setup from the parent
        configurarPropiedades(p);
        
        float origenX = this.posicion.getX();
        float origenY = this.posicion.getY();
        int ancho = this.dimension.getHorizontal();
        int altura = this.dimension.getVertical();
        
        // Draw ellipse instead of rect
        p.ellipse(origenX, origenY, ancho, altura);
    }
    
    @Override
    public boolean mouseIsOver(int punteroX, int punteroY){
    return true;
    }
}