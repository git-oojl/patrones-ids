package models;

import processing.core.PApplet;

public class Nube extends Figura {

    public Nube() {
        super();
        this.dimension = new Dimension(80, 50);
        this.color = 255; // Clouds are white
    }

    @Override
    public void dibujar(PApplet p) {
        p.noStroke(); // Clouds usually don't have borders
        p.fill(this.color);

        float x = this.posicion.getX();
        float y = this.posicion.getY();

        // Draw 3 overlapping circles to make a cloud shape
        p.ellipse(x, y, 50, 50);           // Center
        p.ellipse(x - 30, y + 10, 40, 40); // Left bump
        p.ellipse(x + 30, y + 10, 40, 40); // Right bump
        
        // Restore stroke for other objects
        p.stroke(0);
    }
    
    // --- FIX: Added missing method ---
    @Override
    public boolean mouseIsOver(int coordMouseX, int coordMouseY) {
        // Simple logic: return true if mouse is roughly inside (simplified)
        // or just return false if you don't need click interaction yet.
        return true; 
    }
}