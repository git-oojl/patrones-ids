package models;
import processing.core.PApplet;

// Inherits everything from Figura
public class Caja extends Figura {
    
    // Default constructor
    public Caja() {
        // Calls the default constructor of Figura
        super();
    }
    
    // Full constructor
    public Caja(Posicion posicion, Dimension dimension, Borde borde, int color) {
        // Passes the data up to the Figura constructor
        super(posicion, dimension, borde, color);
    }
    
    @Override
    public void dibujar(PApplet p) {
        configurarPropiedades(p);
        float origenX = this.posicion.getX();
        float origenY = this.posicion.getY();
        int pixelesBase = this.dimension.getHorizontal();
        int pixelesAltura = this.dimension.getVertical();
        
        // Default shape is a rectangle (used by Caja)
        p.rect(origenX, origenY, pixelesBase, pixelesAltura);
    }
    
    @Override
    public boolean mouseIsOver(int punteroX, int punteroY){
        return true;
    }
    
    // No need to write Getters/Setters or Dibujar! 
    // They are all inherited from Figura.
}